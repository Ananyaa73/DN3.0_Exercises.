public class ProxyImage implements Image {
    private String fileName;
    private RealImage realImage;

    public ProxyImage(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void display() {
        if(fileName!=exists())
        {
            Sytem.out.println("File not found");
        }
        else{
            System.out.println("File opened successfully");
        }
        if (realImage == null) {
            realImage = new RealImage(fileName);
        }
        realImage.display();
    }
}
