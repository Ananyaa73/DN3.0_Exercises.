public class ProxyPatternExample {
    public static void main(String[] args) {
        Image i1 = new ProxyImage("photo1.jpg");
        Image i2 = new ProxyImage("photo2.jpg");

        
        i1.display();
        System.out.println("Displayed img1 Successfully");

        
        i1.display();
        System.out.println("Displayed Again");

        
        i2.display();
        System.out.println("Displayed img2 Successfully");
    }
}