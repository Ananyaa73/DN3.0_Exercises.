public class StudentView {
    public void displayStudentDetails(int id,String name, String grade) {
        System.out.println("Student: ");
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Grade: " + grade);
    }
}
