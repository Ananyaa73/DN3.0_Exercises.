public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(String customerId) {
        return "Customer with ID: " + customerId;
    }
}
