public interface CustomerRepository {
    String findCustomerById(int customerId);
}
