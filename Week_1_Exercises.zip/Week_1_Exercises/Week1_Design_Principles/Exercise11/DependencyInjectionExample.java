public class DependencyInjectionExample {
    public static void main(String[] args) {
        // Create an instance of CustomerRepository
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject CustomerRepository into CustomerService
        CustomerService customerService = new CustomerService(customerRepository);

        // Use CustomerService to find a customer
        String customer = customerService.getCustomer("12345");
        System.out.println(customer);
    }
}
