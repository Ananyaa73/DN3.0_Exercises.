public class CustomerService {
    private final CustomerRepository crsty;

    // Constructor Injection
    public CustomerService(CustomerRepository crsty) {
        this.crsty = crsty;
    }

    public String getCustomer(String customerId) {
        return crsty.findCustomerById(customerId);
    }
}

