public class PayTM {
    public void makePayment(double amount) {
        System.out.println("Processing payment through PayTM is:" + amount);
    }
}
