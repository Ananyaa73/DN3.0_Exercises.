public class AdapterPatternExample {
    public static void main(String[] args) {
        // Using PayPal through the adapter
        PayPal payPal = new PayPal();
        PaymentProcessor ppProcessor = new PayPalAdapter(payPal);
        pplProcessor.processPayment(500.0);

        // Using Stripe through the adapter
        PayTM pay = new PayTM();
        PaymentProcessor pProcessor = new PayTMAdapter(pay);
        pProcessor.processPayment(225.0);
    }
}
