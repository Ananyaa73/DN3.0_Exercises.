public class RemoteControl {
    private Command cmd;

    public void setCommand(Command cmd) {
        this.command = cmd;
    }

    public void pressButton() {
        cmd.execute();
    }
}
