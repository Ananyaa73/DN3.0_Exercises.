public class LightOffCommand implements Command {
    private Light lgt;

    public LightOffCommand(Light lgt) {
        this.lgt = lgt;
    }

    @Override
    public void execute() {
        lgt.turnOff();
    }
}
