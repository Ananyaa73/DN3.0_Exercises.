public class LightOnCommand implements Command {
    private Light lgt;

    public LightOnCommand(Light lgt) {
        this.lgt = lgt;
    }

    @Override
    public void execute() {
        lgt.turnOn();
    }
}
