public class PdfDocuments implements PDFDocument {
    @Override
    public void open() {
        System.out.println("PDF is opened.");
    }

    @Override
    public void save() {
        System.out.println("PDF is saved.");
    }

    @Override
    public void edit() {
        System.out.println("PDF is closed");
    }

    @Override
    public void close() {
        System.out.println("PDF is closed.");
    }
}
