public interface ExcelDocument {
    void open();
    void save();
    void edit();
    void close();
}
