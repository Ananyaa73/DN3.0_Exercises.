public class ExcelDocuments implements ExcelDocument {
    @Override
    public void open() {
        System.out.println("Excel is opened.");
    }

    @Override
    public void save() {
        System.out.println("Excel is saved.");
    }

    @Override
    public void edit() {
        System.out.println("Excel is closed");
    }

    @Override
    public void close() {
        System.out.println("Excel is closed.");
    }
}
