public interface PDFDocument {
    void open();
    void save();
    void edit();
    void close();
}
