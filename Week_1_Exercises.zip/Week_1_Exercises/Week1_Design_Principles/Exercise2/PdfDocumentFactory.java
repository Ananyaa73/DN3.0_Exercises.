public class PdfDocumentFactory extends DocumentFactory {
    @Override
    public PDFDocument createDocument() {
        return new PdfDocument();
    }
}
