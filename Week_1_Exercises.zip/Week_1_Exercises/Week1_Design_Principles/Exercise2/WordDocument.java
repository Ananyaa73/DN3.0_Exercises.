public interface WordDocument {
    void open();
    void save();
    void edit();
    void close();
}
