public class WordDocuments implements WordDocument {
    @Override
    public void open() {
        System.out.println("Word is opened.");
    }

    @Override
    public void save() {
        System.out.println("Word is saved.");
    }

    @Override
    public void edit()
    {
        System.out.println("Word is edited");
    }
    @Override
    public void close() {
        System.out.println("Word is closed.");
    }
}
