public class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String messagesent) {
        super.send(messagesent);
        sendSlack(messagesent);
    }

    private void sendSlack(String messagesent) {
        System.out.println("SentSlack along with message: " + messagesent);
    }
}
