public class EmailNotifier implements Notifier {
    @Override
    public void send(String messagesent) {
        System.out.println("Sent email along with message: " + messagesent);
    }
}
