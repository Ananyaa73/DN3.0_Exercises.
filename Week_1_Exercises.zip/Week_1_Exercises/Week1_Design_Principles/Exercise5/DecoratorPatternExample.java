public class DecoratorPatternExample {
    public static void main(String[] args) {
        // Create an EmailNotifier
        Notifier en = new EmailNotifier();

        // Decorate it with SMSNotifierDecorator
        Notifier sn = new SMSNotifierDecorator(en);

        // Further decorate it with SlackNotifierDecorator
        Notifier sln = new SlackNotifierDecorator(sn);

        // Send notifications via multiple channels
        sln.send("This is a test message.");
    }
}
