public class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String messagesent) {
        super.send(messagesent);
        sendSMSMessage(messagesent);
    }

    private void sendSMSMessage(String messagesent) {
        System.out.println("Sent SMS along with message: " + messagesent);
    }
}
