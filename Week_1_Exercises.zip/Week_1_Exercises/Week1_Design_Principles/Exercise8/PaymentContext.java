public class PaymentContext {
    private PaymentStrategy pst;

    public void setPaymentStrategy(PaymentStrategy pst) {
        this.pst = pst;
    }

    public void executePayment(double amount) {
        pst.pay(amount);
    }
}
