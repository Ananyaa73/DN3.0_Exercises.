public class StrategyPatternExample {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234975943123456", "ABC");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.executePayment(110.0);

        PaymentStrategy payPalPayment = new PayPalPayment("abc@example.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.executePayment(545.0);
    }
}
