public class LoggerTest {
    public static void main(String[] args) {
        
        Logger l1 = Logger.getInstance();
        Logger l2 = Logger.getInstance();

        
        if (l1 == l2) {
            System.out.println("Both the instances are same.It is a singleton");
        } else {
            System.out.println("Different instances exist.It is not a singleton");
        }

        
        l1.log("This is a message.");
    }
}
