public class LinearSearchExample {
    
        public static Product linearSearch(Product[] products, int targetProductId) {
        for (Product product : products) {
            if (product.getProductId() == targetProductId) {
                return product;
            }
        }
        return null;    }
    
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(203, "Chair", "Furniture"),
            new Product(305, "Book", "Books"),
            new Product(408, "Shoes", "Fashion"),
            new Product(512, "Watch", "Accessories")
        };
        
        int targetProductId = 305;
        Product foundProduct = linearSearch(products, targetProductId);
        
        if (foundProduct != null) {
            System.out.println("Product found: " + foundProduct);
        } else {
            System.out.println("Product with ID " + targetProductId + " not found.");
        }
    }
}
