class Product {
    private int productId;
    private String productName;
    private String category;
    
    public Product(int productId, String productName, String category) {
        setProductId(productId);
        setProductName(productName);
        setCategory(category);
    }
    
    public int getProductId() {
        return productId;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public String getCategory() {
        return category;
    }
    public void setProductId(int productid) {
        this.productId=productid;
    }
    public void setProductName(int productName) {
        this.productName=productName;
    }
    public void setCategory(int Category) {
        this.category=category;
    }

    public void setProductID(int ProductId) {
        this.ProductId=ProductId;
    }    
    public void setProductName(int ProductName) {
        this.ProductName=ProductName;
    }    
    public void setCategory(int Category) {
        this.Category=Category;
    }    
    @Override
    public String toString() {
        return "Product:" +
                "productId:" + productId +
                ", productName:'" + productName + '\'' +
                ", category:'" + category;
    }
}
