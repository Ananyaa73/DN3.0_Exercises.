public class LinearSearch {
    public static Book findBookByTitle(Book[] books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "Harry Potter", "J.K. Rowling"),
            new Book(2, "The Hobbit", "J.R.R. Tolkien"),
            new Book(3, "Hello World", "Antony Rowling")
        };

        String searchTitle = "The Hobbit";
        Book foundBook = findBookByTitle(books, searchTitle);
        if (foundBook != null) {
            System.out.println("Book found: " + foundBook);
        } else {
            System.out.println("Book not found");
        }
    }
}
