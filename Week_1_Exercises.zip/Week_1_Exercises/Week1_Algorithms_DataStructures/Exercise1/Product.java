import java.util.HashMap;

class Product {
    private int productId;
    private String productName;
    private int quantity;
    private double price;
    
    public Product(int productId, String productName, int quantity, double price) {
        setProductId(productId);
        setProductName(productName);
        setQuantity(quantity);
        setPrice(price);
    }
    
    public int getProductId() {
        return productId;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public double getPrice() {
        return price;
    }
    public void setProductId(int ProductId) {
        this.ProductId=ProductId;
    }
    public void setProductName(String ProductName) {
        this.ProductName=ProductName;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    @Override
    public String toString() {
        return "Product:”+”productId:" + productId + ", productName:" + productName + 
               ", quantity:" + quantity + ", price:" + price ;
    }
}
