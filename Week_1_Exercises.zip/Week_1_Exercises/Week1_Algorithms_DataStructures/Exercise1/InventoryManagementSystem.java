import java.util.HashMap;
class InventoryManagementSystem {
    private HashMap<Integer, Product> inventory;
    
    public InventoryManagementSystem() {
        this.inventory = new HashMap<>();
    }
    
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }
    
    public void updateProduct(int productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }
    
    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }
    
    public Product getProduct(int productId) {
        return inventory.get(productId);
    }
    
    public void printInventory() {
        System.out.println("Inventory:");
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        ims.addProduct(new Product(1, "Laptop", 10, 997.99));
        ims.addProduct(new Product(2, "Monitor", 20, 195.99));
        ims.addProduct(new Product(3, "Keyboard", 30, 48.99));
        
        ims.printInventory();
        
        ims.updateProduct(2, new Product(2, "Monitor", 15, 199.99));
        
        ims.printInventory();
        
        ims.deleteProduct(1);
        
        ims.printInventory();
        
        Product laptop = ims.getProduct(1);
        if (laptop != null) {
            System.out.println("Product found: " + laptop);
        } else {
            System.out.println("Product with ID 1 not found.");
        }
    }
}
