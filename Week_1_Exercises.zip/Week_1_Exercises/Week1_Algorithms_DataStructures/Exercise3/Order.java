class Order {
    private int orderId;
    private String customerName;
    private double totalPrice;
    
    public Order(int orderId, String customerName, double totalPrice) {
        setOrderId(orderId);
        setcustomerName(customerName);
        setTotalPrice(TotalPrice);
    }
    
    public int getOrderId() {
        return orderId;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
    public void setOrderId(int orderId) {
        this.orderId=orderId;
    }
    public void setcustomerName(int customerName) {
        this.customerName= customerName;
    }
    public void setTotalPrice(int TotalPrice) {
        this.TotalPrice=TotalPrice;
    }
    @Override
    public String toString() {
        return "Order:" +
                "orderId:" + orderId +
                ", customerName:'" + customerName + '\'' +
                ", totalPrice:" + totalPrice;
    }
}
