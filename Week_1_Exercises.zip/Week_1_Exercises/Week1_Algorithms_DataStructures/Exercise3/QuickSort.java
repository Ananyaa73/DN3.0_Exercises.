import java.util.Arrays;

public class QuickSort {
    
        public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            
            int pivotIndex = partition(orders, low, high);
            quickSort(orders, low, pivotIndex - 1);
            quickSort(orders, pivotIndex + 1, high);
        }
    }
    
        private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = low - 1; // Index of smaller element
        
        for (int j = low; j < high; j++) {
            
            if (orders[j].getTotalPrice() <= pivot) {
                i++;
                
                
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        
        
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        
        return i + 1;
    }
    
    public static void main(String[] args) {
        
            Order[] orders = {
            new Order(101, "John Doe", 120.50),
            new Order(202, "Jane Smith", 99.99),
            new Order(303, "David Johnson", 175.25),
            new Order(405, "Emily Brown", 150.00)
        };
        
        
        System.out.println("Unsorted Orders:");
        Arrays.stream(orders).forEach(System.out::println);
        
        
        quickSort(orders, 0, orders.length - 1);
        
        
        System.out.println("\nSorted Orders (Quick Sort):");
        Arrays.stream(orders).forEach(System.out::println);
    }
}
