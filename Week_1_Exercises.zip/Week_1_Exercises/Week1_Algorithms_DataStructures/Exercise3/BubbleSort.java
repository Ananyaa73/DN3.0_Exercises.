import java.util.Arrays;

public class BubbleSort {
    
        public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        boolean swapped;
        
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                    swapped = true;
                }
            }
            
            if (!swapped) {
                break;
            }
        }
    }
    
    public static void main(String[] args) {
  
        Order[] orders = {
            new Order(101, "John Doe", 120.50),
            new Order(203, "Jane Smith", 99.99),
            new Order(305, "David Johnson", 175.25),
            new Order(408, "Emily Brown", 150.00)
        };
        
        System.out.println("Unsorted Orders:");
        Arrays.stream(orders).forEach(System.out::println);
        
        bubbleSort(orders);
        
        System.out.println("\nSorted Orders (Bubble Sort):");
        Arrays.stream(orders).forEach(System.out::println);
    }
}
