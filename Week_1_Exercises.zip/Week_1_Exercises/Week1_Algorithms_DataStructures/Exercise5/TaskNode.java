class TaskNode {
        private Task task;
        private TaskNode next;
        

        public TaskNode(Task task) {
            setTask(task);
            setNext(null);
        }
        

        public Task getTask() {
            return task;
        }
        
        public TaskNode getNext() {
            return next;
        }
        
        public void setNext(TaskNode next) {
            this.next = next;
        }
        public void setTask(TaskNode task) {
            this.task = task;
        }

    }
    

    public static void main(String[] args) {
        TaskList taskList = new TaskList();
        

        taskList.addTask(new Task(1, "Task 1", "Pending"));
        taskList.addTask(new Task(2, "Task 2", "In Progress"));
        taskList.addTask(new Task(3, "Task 3", "Completed"));
        

        System.out.println("All Tasks:");
        taskList.traverseTasks();
        

        int searchId = 2;
        System.out.println("\nSearching for task with ID " + searchId + ":");
        Task foundTask = taskList.searchTask(searchId);
        if (foundTask != null) {
            System.out.println(foundTask);
        } else {
            System.out.println("Task not found.");
        }
        

        int deleteId = 1;
        System.out.println("\nDeleting task with ID " + deleteId + ":");
        if (taskList.deleteTask(deleteId)) {
            System.out.println("Task deleted successfully.");
        } else {
            System.out.println("Task not found.");
        }
        

        System.out.println("\nTasks after deletion:");
        taskList.traverseTasks();
    }
}
