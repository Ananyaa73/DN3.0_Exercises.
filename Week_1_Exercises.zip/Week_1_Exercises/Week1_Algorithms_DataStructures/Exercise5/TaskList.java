public class TaskList {
    private TaskNode head;
    

    public TaskList() {
        head = null;
    }
    

    public boolean isEmpty() {
        return head == null;
    }
    

    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        
        if (isEmpty()) {
            head = newNode;
        } else {
            TaskNode current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }
    

    public Task searchTask(int taskId) {
        TaskNode current = head;
        while (current != null) {
            if (current.getTask().getTaskId() == taskId) {
                return current.getTask();
            }
            current = current.getNext();
        }
        return null; 
    }
    

    public void traverseTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println(current.getTask());
            current = current.getNext();
        }
    }
    

    public boolean deleteTask(int taskId) {
        if (isEmpty()) {
            return false; // List is empty
        }
        
        if (head.getTask().getTaskId() == taskId) {
            head = head.getNext();
            return true;
        }
        
        TaskNode prev = head;
        TaskNode current = head.getNext();
        
        while (current != null) {
            if (current.getTask().getTaskId() == taskId) {
                prev.setNext(current.getNext());
                return true;
            }
            prev = current;
            current = current.getNext();
        }
        
        return false; 
    }
    

    