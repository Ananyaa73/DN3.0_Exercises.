public class EmployeeManagement {
    private Employee[] employees;
    private int size;
    private static final int INITIAL_CAPACITY = 10;     

    public EmployeeManagement() {
        employees = new Employee[INITIAL_CAPACITY];
        size = 0;
    }
    

    public void addEmployee(Employee emp) {

        if (size == employees.length) {
            resizeArray();
        }
        
        employees[size++] = emp;
    }
    

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null; 
    }
    

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }
    

    public boolean deleteEmployee(int employeeId) {
        int index = -1;
        

        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                index = i;
                break;
            }
        }
        

        if (index != -1) {

            for (int i = index; i < size - 1; i++) {
                employees[i] = employees[i + 1];
            }
            employees[size - 1] = null; 
            size--;
            return true;
        }
        
        return false; 
    }
    

    private void resizeArray() {
        int newCapacity = employees.length * 2;
        Employee[] newArray = new Employee[newCapacity];
        System.arraycopy(employees, 0, newArray, 0, size);
        employees = newArray;
    }
    
    // Main method for testing
    public static void main(String[] args) {
        EmployeeManagement empManager = new EmployeeManagement();
        

        empManager.addEmployee(new Employee(101, "John Doe", "Manager", 50000));
        empManager.addEmployee(new Employee(102, "Jane Smith", "Developer", 60000));
        empManager.addEmployee(new Employee(103, "David Johnson", "Analyst", 55000));
        

        System.out.println("All Employees:");
        empManager.traverseEmployees();
        

        int searchId = 102;
        System.out.println("\nSearching for employee with ID " + searchId + ":");
        Employee foundEmployee = empManager.searchEmployee(searchId);
        if (foundEmployee != null) {
            System.out.println(foundEmployee);
        } else {
            System.out.println("Employee not found.");
        }
        

        int deleteId = 101;
        System.out.println("\nDeleting employee with ID " + deleteId + ":");
        if (empManager.deleteEmployee(deleteId)) {
            System.out.println("Employee deleted successfully.");
        } else {
            System.out.println("Employee not found.");
        }
        

        System.out.println("\nEmployees after deletion:");
        empManager.traverseEmployees();
    }
}
