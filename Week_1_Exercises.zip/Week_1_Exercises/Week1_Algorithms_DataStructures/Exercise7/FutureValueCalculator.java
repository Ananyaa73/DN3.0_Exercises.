public class FutureValueCalculator {


    public static double calculateFutureValue(double initialValue, double growthRate, int periods) {
  
        if (periods == 0) {
            return initialValue;
        } else {
 
            double futureValue = initialValue * (1 + growthRate);

            return calculateFutureValue(futureValue, growthRate, periods - 1);
        }
    }


    public static void main(String[] args) {
        double initialValue = 110; 
        double growthRate = 0.07;   
        int periods = 20;          

        
        double futureValue = calculateFutureValue(initialValue, growthRate, periods);
        System.out.println("Future value after " + periods + " periods: $" + futureValue);
    }
}
